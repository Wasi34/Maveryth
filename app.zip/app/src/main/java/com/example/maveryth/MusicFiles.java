package com.example.maveryth;

import android.provider.MediaStore;
import android.view.View;

import static com.example.maveryth.MainActivity.shuffleBoolean;

public class MusicFiles {
    //423pt2
    private String path;
    private String title;
    private String artist;
    private String album;
    private String duration;


    public MusicFiles(String path, String title, String artist, String album, String duration) {
        this.path = path;
        this.title = title;
        this.artist = artist;
        this.album = album;
        this.duration = duration;

    }

    public MusicFiles(){

    }

    public String getPath() {
        return path;
    }

    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }

    public String getAlbum() {
        return album;
    }

    public String getDuration() {
        return duration;
    }


    public void setPath(String path) {
        this.path = path;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }


}
